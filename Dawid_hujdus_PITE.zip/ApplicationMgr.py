from InputReader import InputReader

program = InputReader()
program.validate()
program.solve()
program.print()
