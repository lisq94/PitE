class InputValidator:
    _message = ""

    def __init__(self, first, second):
        self.first = first
        self.second = second
        print("Trwa walidacja")

    def validate(self):
        if not self.isEnoughParameters(3):
            return False
        if not self.isNumber():
            return False
        if not self.isOznaczony():
            return False


    def isEnoughParameters(self, count):
        if len(self.first) == count and len(self.second) == count:
            return True
        else:
            self._message = "Podana zła liczba parametrów"
            return False

    def isNumber(self):
        val = ""
        try:
            for a in self.first:
                val = int(a)
            for a in self.second:
                val = int(a)
        except ValueError:
            self._message = "Jeden z argumentów nie jest liczbą: " + val

    def isOznaczony(self):
        if self.first[0]*self.second[1]-self.second[0]*self.first[1] != 0:
            return True
        else:
            self._message = "Układ równań nie jest oznaczony!"
            return False

    def getMessage(self):
        print(self._message)