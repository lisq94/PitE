from InputValidator import InputValidator
from Solver import Solver

class InputReader:
    def __init__(self):
        print("Podaj współczynniki pierwszego równania ax + by = c")
        self.first = input("Podaj w formacie a b c: ")
        print("Podaj współczynniki drugiego równania ax + by = c")
        self.second = input("Podaj w formacie a b c: ")

    def validate(self):
        self.first = self.first.split(" ")
        self.second = self.second.split(" ")
        temp = InputValidator(self.first, self.second)
        if not temp.validate():
            temp.getMessage()
            exit()
        print("Walidacja pomyślna")

    def solve(self):
        matrix = [self.first[0], self.first[1],self.first[2], self.second[0], self.second[1], self.second[2]]
        temp = Solver(matrix)
    def print(self):
        print(self.first)
        print(self.second)
