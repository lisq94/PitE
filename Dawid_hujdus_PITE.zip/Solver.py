class Solver:
    def __init__(self,matrix):
        W = matrix[0]*matrix[1]-matrix[3]*matrix[4]
        Wx = matrix[2]*matrix[4]-matrix[3]*matrix[5]
        Wy = matrix[0]*matrix[5]-matrix[2]*matrix[1]
        # nie dziala pewnie
        x=Wx/W
        y=Wy/W
        print("x="+x)
        print("y="+y)